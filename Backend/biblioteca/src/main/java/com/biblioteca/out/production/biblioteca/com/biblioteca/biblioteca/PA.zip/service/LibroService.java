package com.biblioteca.biblioteca.service;

import com.biblioteca.biblioteca.entity.Libro;
import java.util.List;

public interface LibroService {
    Libro crear(Libro libro);
    Libro obtenerPorId(Long id);
    List<Libro> listar();
    Libro actualizar(Long id, Libro libro);
    void eliminar(Long id);
}
