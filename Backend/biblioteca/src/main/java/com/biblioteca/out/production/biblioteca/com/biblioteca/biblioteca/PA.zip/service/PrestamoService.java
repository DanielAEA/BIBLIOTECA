package com.biblioteca.biblioteca.service;

import com.biblioteca.biblioteca.entity.Prestamo;
import java.util.List;

public interface PrestamoService {
    Prestamo crear(Prestamo prestamo);
    Prestamo obtenerPorId(Long id);
    List<Prestamo> listar();
    Prestamo actualizar(Long id, Prestamo prestamo);
    void eliminar(Long id);

    Prestamo devolverLibro(Long idPrestamo);
}
