package com.biblioteca.biblioteca.service.impl;

import com.biblioteca.biblioteca.entity.PrecioMulta;
import com.biblioteca.biblioteca.repository.PrecioMultaRepository;
import com.biblioteca.biblioteca.service.PrecioMultaService;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class PrecioMultaServiceImpl implements PrecioMultaService {

    private final PrecioMultaRepository precioMultaRepository;

    public PrecioMultaServiceImpl(PrecioMultaRepository precioMultaRepository) {
        this.precioMultaRepository = precioMultaRepository;
    }

    @Override
    public PrecioMulta crear(PrecioMulta precioMulta) { return precioMultaRepository.save(precioMulta); }

    @Override
    public PrecioMulta obtenerPorId(Long id) {
        return precioMultaRepository.findById(id).orElse(null);
    }

    @Override
    public List<PrecioMulta> listar() { return precioMultaRepository.findAll(); }

    @Override
    public PrecioMulta actualizar(Long id, PrecioMulta precioMulta) {
        precioMulta.setId(id);
        return precioMultaRepository.save(precioMulta);
    }

    @Override
    public void eliminar(Long id) {
        precioMultaRepository.deleteById(id);
    }

    @Override
    public PrecioMulta obtenerPrecioVigente() {
        return precioMultaRepository.findTopByOrderByVigenteDesdeDesc();
    }
}
