package com.biblioteca.biblioteca.service;

import com.biblioteca.biblioteca.entity.Permisos;
import java.util.List;

public interface PermisoService {
    Permisos crear(Permisos permiso);
    Permisos obtenerPorId(Long id);
    List<Permisos> listar();
    Permisos actualizar(Long id, Permisos permiso);
    void eliminar(Long id);
}
