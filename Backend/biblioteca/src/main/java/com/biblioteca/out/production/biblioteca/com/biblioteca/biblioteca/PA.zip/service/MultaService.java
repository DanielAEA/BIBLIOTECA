package com.biblioteca.biblioteca.service;

import com.biblioteca.biblioteca.entity.Multa;
import java.util.List;

public interface MultaService {
    Multa crear(Multa multa);
    Multa obtenerPorId(Long id);
    List<Multa> listar();
    Multa actualizar(Long id, Multa multa);
    void eliminar(Long id);
}
