package com.biblioteca.biblioteca.service.impl;

import com.biblioteca.biblioteca.entity.Permisos;
import com.biblioteca.biblioteca.repository.PermisoRepository;
import com.biblioteca.biblioteca.service.PermisoService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PermisoServiceImpl implements PermisoService {

    private final PermisoRepository permisoRepository;

    public PermisoServiceImpl(PermisoRepository permisoRepository) {
        this.permisoRepository = permisoRepository;
    }

    @Override
    public Permisos crear(Permisos permiso) {
        return permisoRepository.save(permiso);
    }

    @Override
    public Permisos obtenerPorId(Long id) {
        return permisoRepository.findById(id).orElse(null);
    }

    @Override
    public List<Permisos> listar() {
        return permisoRepository.findAll();
    }

    @Override
    public Permisos actualizar(Long id, Permisos permiso) {
        permiso.setId(id);
        return permisoRepository.save(permiso);
    }

    @Override
    public void eliminar(Long id) {
        permisoRepository.deleteById(id);
    }
}
