package com.biblioteca.biblioteca.service;

import com.biblioteca.biblioteca.entity.Autor;
import java.util.List;

public interface AutorService {
    Autor crear(Autor autor);
    Autor obtenerPorId(Long id);
    List<Autor> listar();
    Autor actualizar(Long id, Autor autor);
    void eliminar(Long id);
}
