package com.biblioteca.biblioteca.entity;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "ejemplar")
public class Ejemplar {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String codigo;

    // Ejemplar N — 1 Libro
    @ManyToOne(optional = false)
    @JoinColumn(name = "libro_id")
    private Libro libro;

    private Boolean disponible = true;

    // Ejemplar 1 — N Préstamos
    @OneToMany(mappedBy = "ejemplar", cascade = CascadeType.ALL)
    private List<Prestamo> prestamos;

    public Ejemplar() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public Libro getLibro() { return libro; }
    public void setLibro(Libro libro) { this.libro = libro; }
    public Boolean getDisponible() { return disponible; }
    public void setDisponible(Boolean disponible) { this.disponible = disponible; }
    public List<Prestamo> getPrestamos() { return prestamos; }
    public void setPrestamos(List<Prestamo> prestamos) { this.prestamos = prestamos; }
}
