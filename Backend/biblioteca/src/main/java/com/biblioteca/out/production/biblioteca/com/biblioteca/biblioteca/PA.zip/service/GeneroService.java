package com.biblioteca.biblioteca.service;

import com.biblioteca.biblioteca.entity.Genero;
import java.util.List;

public interface GeneroService {
    Genero crear(Genero genero);
    Genero obtenerPorId(Long id);
    List<Genero> listar();
    Genero actualizar(Long id, Genero genero);
    void eliminar(Long id);
}
