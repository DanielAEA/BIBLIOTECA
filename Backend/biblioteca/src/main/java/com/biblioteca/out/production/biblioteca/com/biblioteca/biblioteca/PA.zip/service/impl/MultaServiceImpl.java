package com.biblioteca.biblioteca.service.impl;

import com.biblioteca.biblioteca.entity.Multa;
import com.biblioteca.biblioteca.repository.MultaRepository;
import com.biblioteca.biblioteca.service.MultaService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MultaServiceImpl implements MultaService {

    private final MultaRepository multaRepository;

    public MultaServiceImpl(MultaRepository multaRepository) {
        this.multaRepository = multaRepository;
    }

    @Override
    public Multa crear(Multa multa) { return multaRepository.save(multa); }

    @Override
    public Multa obtenerPorId(Long id) {
        return multaRepository.findById(id).orElse(null);
    }

    @Override
    public List<Multa> listar() { return multaRepository.findAll(); }

    @Override
    public Multa actualizar(Long id, Multa multa) {
        multa.setId(id);
        return multaRepository.save(multa);
    }

    @Override
    public void eliminar(Long id) {
        multaRepository.deleteById(id);
    }
}
