package com.biblioteca.biblioteca.service;

import com.biblioteca.biblioteca.entity.Editorial;
import java.util.List;

public interface EditorialService {
    Editorial crear(Editorial editorial);
    Editorial obtenerPorId(Long id);
    List<Editorial> listar();
    Editorial actualizar(Long id, Editorial editorial);
    void eliminar(Long id);
}
