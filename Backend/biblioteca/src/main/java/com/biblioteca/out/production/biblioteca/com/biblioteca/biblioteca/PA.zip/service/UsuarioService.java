package com.biblioteca.biblioteca.service;

import com.biblioteca.biblioteca.entity.Usuario;
import java.util.List;

public interface UsuarioService {
    Usuario crear(Usuario usuario);
    Usuario obtenerPorId(Long id);
    List<Usuario> listar();
    Usuario actualizar(Long id, Usuario usuario);
    void eliminar(Long id);
}
