package com.biblioteca.biblioteca.service.impl;

import com.biblioteca.biblioteca.entity.*;
import com.biblioteca.biblioteca.repository.*;
import com.biblioteca.biblioteca.service.PrestamoService;
import com.biblioteca.biblioteca.service.PrecioMultaService;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
public class PrestamoServiceImpl implements PrestamoService {

    private final PrestamoRepository prestamoRepository;
    private final EjemplarRepository ejemplarRepository;
    private final MultaRepository multaRepository;
    private final PrecioMultaService precioMultaService;

    public PrestamoServiceImpl(
            PrestamoRepository prestamoRepository,
            EjemplarRepository ejemplarRepository,
            MultaRepository multaRepository,
            PrecioMultaService precioMultaService
    ) {
        this.prestamoRepository = prestamoRepository;
        this.ejemplarRepository = ejemplarRepository;
        this.multaRepository = multaRepository;
        this.precioMultaService = precioMultaService;
    }

    @Override
    public Prestamo crear(Prestamo prestamo) {
        Ejemplar ej = prestamo.getEjemplar();
        ej.setDisponible(false);
        ejemplarRepository.save(ej);

        prestamo.setFechaPrestamo(LocalDate.now());
        prestamo.setFechaDevolucion(LocalDate.now().plusDays(15));

        return prestamoRepository.save(prestamo);
    }

    @Override
    public Prestamo obtenerPorId(Long id) {
        return prestamoRepository.findById(id).orElse(null);
    }

    @Override
    public List<Prestamo> listar() {
        return prestamoRepository.findAll();
    }

    @Override
    public Prestamo actualizar(Long id, Prestamo prestamo) {
        prestamo.setId(id);
        return prestamoRepository.save(prestamo);
    }

    @Override
    public void eliminar(Long id) {
        prestamoRepository.deleteById(id);
    }

    @Override
    public Prestamo devolverLibro(Long idPrestamo) {
        Prestamo prestamo = obtenerPorId(idPrestamo);
        if (prestamo == null) return null;

        prestamo.setDevuelto(true);

        Ejemplar ej = prestamo.getEjemplar();
        ej.setDisponible(true);
        ejemplarRepository.save(ej);

        // Calcular multa si aplica
        if (LocalDate.now().isAfter(prestamo.getFechaDevolucion())) {
            long diasAtraso = ChronoUnit.DAYS.between(
                    prestamo.getFechaDevolucion(),
                    LocalDate.now()
            );

            PrecioMulta precio = precioMultaService.obtenerPrecioVigente();

            Multa multa = new Multa();
            multa.setPrestamo(prestamo);
            multa.setPrecioMulta(precio);
            multa.setDiasAtraso((int) diasAtraso);
            multa.setTotal(precio.getValorPorDia() * diasAtraso);

            multaRepository.save(multa);
            prestamo.setMulta(multa);
        }

        return prestamoRepository.save(prestamo);
    }
}
