package com.biblioteca.biblioteca.service;

import com.biblioteca.biblioteca.entity.PrecioMulta;
import java.util.List;

public interface PrecioMultaService {
    PrecioMulta crear(PrecioMulta precioMulta);
    PrecioMulta obtenerPorId(Long id);
    List<PrecioMulta> listar();
    PrecioMulta actualizar(Long id, PrecioMulta precioMulta);
    void eliminar(Long id);

    PrecioMulta obtenerPrecioVigente();
}
