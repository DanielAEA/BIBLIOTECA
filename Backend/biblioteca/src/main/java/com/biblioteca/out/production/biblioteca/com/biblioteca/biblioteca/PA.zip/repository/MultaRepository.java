package com.biblioteca.biblioteca.repository;

import com.biblioteca.biblioteca.entity.Multa;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MultaRepository extends JpaRepository<Multa, Long> {

}
