package com.biblioteca.biblioteca.controller;

import com.biblioteca.biblioteca.entity.Permisos;
import com.biblioteca.biblioteca.service.PermisoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/permisos")
@CrossOrigin(origins = "*")
public class PermisosController {

    private final PermisoService permisoService;

    public PermisosController(PermisoService permisoService) {
        this.permisoService = permisoService;
    }

    @GetMapping
    public List<Permisos> listar() {
        return permisoService.listar();
    }

    @GetMapping("/{id}")
    public Permisos obtener(@PathVariable Long id) {
        return permisoService.obtenerPorId(id);
    }

    @PostMapping
    public Permisos crear(@RequestBody Permisos permiso) {
        return permisoService.crear(permiso);
    }

    @PutMapping("/{id}")
    public Permisos actualizar(@PathVariable Long id, @RequestBody Permisos permiso) {
        return permisoService.actualizar(id, permiso);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        permisoService.eliminar(id);
    }
}
