package com.biblioteca.biblioteca.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "multa")
public class Multa {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Multa 1 — 1 Préstamo
    @OneToOne
    @JoinColumn(name = "prestamo_id", unique = true)
    private Prestamo prestamo;

    // Multa N — 1 PrecioMulta
    @ManyToOne(optional = false)
    @JoinColumn(name = "precio_multa_id")
    private PrecioMulta precioMulta;

    @Column(name = "dias_atraso", nullable = false)
    private Integer diasAtraso;

    @Column(nullable = false)
    private Double total;

    public Multa() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Prestamo getPrestamo() { return prestamo; }
    public void setPrestamo(Prestamo prestamo) { this.prestamo = prestamo; }
    public PrecioMulta getPrecioMulta() { return precioMulta; }
    public void setPrecioMulta(PrecioMulta precioMulta) { this.precioMulta = precioMulta; }
    public Integer getDiasAtraso() { return diasAtraso; }
    public void setDiasAtraso(Integer diasAtraso) { this.diasAtraso = diasAtraso; }
    public Double getTotal() { return total; }
    public void setTotal(Double total) { this.total = total; }
}
