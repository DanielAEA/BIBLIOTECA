package com.biblioteca.biblioteca.service.impl;

import com.biblioteca.biblioteca.entity.Editorial;
import com.biblioteca.biblioteca.repository.EditorialRepository;
import com.biblioteca.biblioteca.service.EditorialService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EditorialServiceImpl implements EditorialService {

    private final EditorialRepository editorialRepository;

    public EditorialServiceImpl(EditorialRepository editorialRepository) {
        this.editorialRepository = editorialRepository;
    }

    @Override
    public Editorial crear(Editorial editorial) { return editorialRepository.save(editorial); }

    @Override
    public Editorial obtenerPorId(Long id) {
        return editorialRepository.findById(id).orElse(null);
    }

    @Override
    public List<Editorial> listar() { return editorialRepository.findAll(); }

    @Override
    public Editorial actualizar(Long id, Editorial editorial) {
        editorial.setId(id);
        return editorialRepository.save(editorial);
    }

    @Override
    public void eliminar(Long id) {
        editorialRepository.deleteById(id);
    }
}
