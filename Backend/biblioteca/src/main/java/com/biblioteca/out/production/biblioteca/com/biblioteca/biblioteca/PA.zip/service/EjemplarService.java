package com.biblioteca.biblioteca.service;

import com.biblioteca.biblioteca.entity.Ejemplar;
import java.util.List;

public interface EjemplarService {
    Ejemplar crear(Ejemplar ejemplar);
    Ejemplar obtenerPorId(Long id);
    List<Ejemplar> listar();
    Ejemplar actualizar(Long id, Ejemplar ejemplar);
    void eliminar(Long id);
}
