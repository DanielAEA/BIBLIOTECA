package com.biblioteca.biblioteca.service.impl;

import com.biblioteca.biblioteca.entity.Autor;
import com.biblioteca.biblioteca.repository.AutorRepository;
import com.biblioteca.biblioteca.service.AutorService;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class AutorServiceImpl implements AutorService {

    private final AutorRepository autorRepository;

    public AutorServiceImpl(AutorRepository autorRepository) {
        this.autorRepository = autorRepository;
    }

    @Override
    public Autor crear(Autor autor) { return autorRepository.save(autor); }

    @Override
    public Autor obtenerPorId(Long id) {
        return autorRepository.findById(id).orElse(null);
    }

    @Override
    public List<Autor> listar() { return autorRepository.findAll(); }

    @Override
    public Autor actualizar(Long id, Autor autor) {
        autor.setId(id);
        return autorRepository.save(autor);
    }

    @Override
    public void eliminar(Long id) {
        autorRepository.deleteById(id);
    }
}
