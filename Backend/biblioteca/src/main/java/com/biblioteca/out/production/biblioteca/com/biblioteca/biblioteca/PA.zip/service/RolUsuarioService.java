package com.biblioteca.biblioteca.service;

import com.biblioteca.biblioteca.entity.RolUsuario;
import java.util.List;

public interface RolUsuarioService {
    RolUsuario crear(RolUsuario rol);
    RolUsuario obtenerPorId(Long id);
    List<RolUsuario> listar();
    RolUsuario actualizar(Long id, RolUsuario rol);
    void eliminar(Long id);
}

