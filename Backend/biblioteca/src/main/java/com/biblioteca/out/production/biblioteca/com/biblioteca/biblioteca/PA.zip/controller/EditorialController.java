package com.biblioteca.biblioteca.controller;

import com.biblioteca.biblioteca.entity.Editorial;
import com.biblioteca.biblioteca.service.EditorialService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/editoriales")
@CrossOrigin(origins = "*")
public class EditorialController {

    private final EditorialService editorialService;

    public EditorialController(EditorialService editorialService) {
        this.editorialService = editorialService;
    }

    @GetMapping
    public List<Editorial> listar() {
        return editorialService.listar();
    }

    @GetMapping("/{id}")
    public Editorial obtener(@PathVariable Long id) {
        return editorialService.obtenerPorId(id);
    }

    @PostMapping
    public Editorial crear(@RequestBody Editorial editorial) {
        return editorialService.crear(editorial);
    }

    @PutMapping("/{id}")
    public Editorial actualizar(@PathVariable Long id, @RequestBody Editorial editorial) {
        return editorialService.actualizar(id, editorial);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        editorialService.eliminar(id);
    }
}
