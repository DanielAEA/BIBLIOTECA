package com.biblioteca.biblioteca.controller;

import com.biblioteca.biblioteca.entity.RolUsuario;
import com.biblioteca.biblioteca.service.RolUsuarioService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/roles")
@CrossOrigin(origins = "*")
public class RolUsuarioController {

    private final RolUsuarioService rolUsuarioService;

    public RolUsuarioController(RolUsuarioService rolUsuarioService) {
        this.rolUsuarioService = rolUsuarioService;
    }

    @GetMapping
    public List<RolUsuario> listar() {
        return rolUsuarioService.listar();
    }

    @GetMapping("/{id}")
    public RolUsuario obtener(@PathVariable Long id) {
        return rolUsuarioService.obtenerPorId(id);
    }

    @PostMapping
    public RolUsuario crear(@RequestBody RolUsuario rol) {
        return rolUsuarioService.crear(rol);
    }

    @PutMapping("/{id}")
    public RolUsuario actualizar(@PathVariable Long id, @RequestBody RolUsuario rol) {
        return rolUsuarioService.actualizar(id, rol);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        rolUsuarioService.eliminar(id);
    }
}
